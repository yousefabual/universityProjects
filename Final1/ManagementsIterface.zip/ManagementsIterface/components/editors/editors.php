<?php

include_once dirname(__FILE__) . '/dynamic_combobox.php';
include_once dirname(__FILE__) . '/checkbox.php';
include_once dirname(__FILE__) . '/checkboxgroup.php';
include_once dirname(__FILE__) . '/color.php';
include_once dirname(__FILE__) . '/combobox.php';
include_once dirname(__FILE__) . '/datetime.php';
include_once dirname(__FILE__) . '/html_wysiwyg.php';
include_once dirname(__FILE__) . '/imageuploader.php';
include_once dirname(__FILE__) . '/multivalue_select.php';
include_once dirname(__FILE__) . '/remote_multivalue_select.php';
include_once dirname(__FILE__) . '/radio.php';
include_once dirname(__FILE__) . '/range.php';
include_once dirname(__FILE__) . '/spin.php';
include_once dirname(__FILE__) . '/text.php';
include_once dirname(__FILE__) . '/textarea.php';
include_once dirname(__FILE__) . '/time.php';
include_once dirname(__FILE__) . '/masked.php';
include_once dirname(__FILE__) . '/validators.php';
include_once dirname(__FILE__) . '/static_editor.php';
include_once dirname(__FILE__) . '/cascading_combobox.php';
include_once dirname(__FILE__) . '/dynamic_cascading_combobox.php';
include_once dirname(__FILE__) . '/multi_uploader.php';
include_once dirname(__FILE__) . '/autocomplete_editor.php';
include_once dirname(__FILE__) . '/signature_editor.php';
include_once dirname(__FILE__) . '/toggle_editor.php';
